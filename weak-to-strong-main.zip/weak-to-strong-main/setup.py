import setuptools

setuptools.setup(
    name="weak_to_strong",
    version="0.1",
    description="Weak-to-strong generalization",
    url="#",
    author="OpenAI",
    author_email="generalization@openai.com",
    packages=setuptools.find_packages(),
    zip_safe=False,
)
